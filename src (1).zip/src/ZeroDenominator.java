public class ZeroDenominator extends RuntimeException {
}

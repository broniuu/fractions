public class Main {
    public static void main(String[] args) {
        Fraction firstFraction = new Fraction(3, 0);
        Fraction secondFraction = new Fraction(4, 7);
        firstFraction.shorten();

/*        firstFraction.add(secondFraction);
        firstFraction.setNumerator(3);
        firstFraction.setDenominator(5);
        firstFraction.substract(secondFraction);
        firstFraction.setNumerator(10);
        firstFraction.setDenominator(25);
        firstFraction.shorten();
        firstFraction.setDenominator(1);*/
    }
}
